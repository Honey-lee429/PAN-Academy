INSERT INTO tb_tabelinha (pessoa, preco) VALUES ('Luiza', 20.0);
INSERT INTO tb_tabelinha (pessoa, preco) VALUES ('Marcelo', 220.0);
INSERT INTO tb_tabelinha (pessoa, preco) VALUES ('Gabriela', 150.0);
